/** @type {import('next').NextConfig} */
const nextConfig = {}

module.exports = nextConfig

// const withPWA = require('next-pwa');

// module.exports = withPWA({
//   pwa: {
//     dest: 'public', // Output directory for generated service worker
//     disable: process.env.NODE_ENV === 'development', // Disable PWA in development
//   },
// });